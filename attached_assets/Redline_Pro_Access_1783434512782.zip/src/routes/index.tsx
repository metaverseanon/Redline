import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactElement } from "react";
import {
  X,
  Check,
  Sparkles,
  Trophy,
  Infinity as InfinityIcon,
  Bell,
  Share2,
  Flag,
  Gauge,
  Music,
  ChevronRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Paywall,
});

type Slide = {
  key: string;
  title: string;
  lines: string[];
  visual: () => ReactElement;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
};

const SLIDES: Slide[] = [
  {
    key: "coach",
    title: "AI Drive Coach",
    lines: [
      "Personal insights on every drive",
      "Braking, cornering & acceleration tips",
      "Improve lap after lap, week after week",
    ],
    icon: Sparkles,
    visual: SpeedoVisual,
  },
  {
    key: "leaderboard",
    title: "Full Leaderboard Access",
    lines: [
      "Compete with friends & drivers worldwide",
      "Climb the global driving charts",
      "See how you rank against others",
    ],
    icon: Trophy,
    visual: LeaderboardVisual,
  },
  {
    key: "unlimited",
    title: "Unlimited Drive Recordings",
    lines: [
      "Record every trip. No caps. No limits.",
      "Full history saved to your garage",
      "Never lose a session again",
    ],
    icon: InfinityIcon,
    visual: RecordingsVisual,
  },
  {
    key: "alerts",
    title: "Friends Boards Leave Alerts",
    lines: [
      "Know the moment your record falls",
      "Instant push when a friend beats you",
      "React fast. Reclaim your spot.",
    ],
    icon: Bell,
    visual: AlertsVisual,
  },
  {
    key: "invites",
    title: "iOS Share‑Sheet Invites",
    lines: [
      "Invite friends straight from iMessage",
      "One tap to join your private boards",
      "Native, fast, and beautifully integrated",
    ],
    icon: Share2,
    visual: InvitesVisual,
  },
  {
    key: "challenges",
    title: "Custom Challenges & Cash Rewards",
    lines: [
      "Create challenges with countdowns",
      "Real cash prizes for winners",
      "Turn every drive into a competition",
    ],
    icon: Flag,
    visual: ChallengesVisual,
  },
  {
    key: "soundtrack",
    title: "Drive Soundtracks",
    lines: [
      "Pair songs to your best drives",
      "Auto‑attached to recaps and posts",
      "Relive every run with your music",
    ],
    icon: Music,
    visual: SoundtrackVisual,
  },
];

function Paywall() {
  const [plan, setPlan] = useState<"annual" | "weekly">("annual");
  const [index, setIndex] = useState(0);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const autoplayRef = useRef<number | null>(null);

  const haptic = () => {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate?.(8);
  };

  // Track active slide from scroll
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const i = Math.round(el.scrollLeft / el.clientWidth);
        setIndex(Math.max(0, Math.min(SLIDES.length - 1, i)));
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      el.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  // Autoplay (pauses on interaction)
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    let paused = false;
    const pause = () => {
      paused = true;
      if (autoplayRef.current) window.clearInterval(autoplayRef.current);
    };
    el.addEventListener("pointerdown", pause, { once: true });
    autoplayRef.current = window.setInterval(() => {
      if (paused || !scrollerRef.current) return;
      const next = (Math.round(el.scrollLeft / el.clientWidth) + 1) % SLIDES.length;
      el.scrollTo({ left: next * el.clientWidth, behavior: "smooth" });
    }, 4200);
    return () => {
      if (autoplayRef.current) window.clearInterval(autoplayRef.current);
    };
  }, []);

  const goTo = (i: number) => {
    const el = scrollerRef.current;
    if (!el) return;
    haptic();
    el.scrollTo({ left: i * el.clientWidth, behavior: "smooth" });
  };

  return (
    <main className="relative min-h-screen bg-background text-foreground selection:bg-primary/40">
      {/* Top bar */}
      <div className="relative z-20 mx-auto flex max-w-xl items-center justify-between px-5 pt-5">
        <span className="inline-flex items-center gap-2 rounded-md bg-white px-2.5 py-1 font-display text-[11px] font-bold uppercase tracking-[0.2em] text-black">
          <span>🏁</span> Pro
        </span>
        <button
          onClick={haptic}
          aria-label="Close"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-black shadow-lg transition-transform active:scale-90"
        >
          <X className="h-4 w-4" strokeWidth={2.5} />
        </button>
      </div>

      {/* Carousel */}
      <section className="relative mt-3">
        <div
          ref={scrollerRef}
          className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto overscroll-x-contain scroll-smooth"
          style={{ scrollSnapType: "x mandatory" }}
        >
          {SLIDES.map((s) => (
            <SlideCard key={s.key} slide={s} />
          ))}
        </div>

        {/* Dots */}
        <div className="mt-4 flex items-center justify-center gap-2">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={[
                "h-1.5 rounded-full transition-all duration-300",
                i === index
                  ? "w-6 bg-primary shadow-[0_0_10px_theme(colors.primary)]"
                  : "w-1.5 bg-white/25 hover:bg-white/40",
              ].join(" ")}
            />
          ))}
        </div>
      </section>

      {/* Plans */}
      <section className="mx-auto mt-6 max-w-xl space-y-3 px-5">
        <PlanCard
          selected={plan === "annual"}
          onSelect={() => {
            haptic();
            setPlan("annual");
          }}
          title="Annual"
          subtitle="$2.50 / mo · billed yearly"
          price="$29.99"
          cadence="per year"
          strike="$59.88"
          badge="SAVE 50%"
        />
        <PlanCard
          selected={plan === "weekly"}
          onSelect={() => {
            haptic();
            setPlan("weekly");
          }}
          title="Weekly"
          subtitle="Cancel anytime"
          price="$4.99"
          cadence="per week"
        />
      </section>

      {/* CTA */}
      <div className="mx-auto max-w-xl px-5 pt-5 pb-8">
        <button
          onClick={haptic}
          className="group relative flex h-14 w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-primary font-display text-[15px] font-bold uppercase tracking-[0.14em] text-primary-foreground shadow-[0_16px_50px_-12px_rgba(225,6,0,0.7)] transition-transform active:scale-[0.985]"
        >
          <span
            className="pointer-events-none absolute inset-0 opacity-0 transition-opacity group-hover:opacity-100"
            style={{
              background:
                "linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent)",
              backgroundSize: "200% 100%",
              animation: "shimmer 1.8s linear infinite",
            }}
          />
          Start {plan === "annual" ? "Yearly" : "Weekly"}
          <ChevronRight className="h-5 w-5" strokeWidth={2.5} />
        </button>

        <div className="mt-4 flex items-center justify-center gap-4 text-[12px] text-muted-foreground">
          <FooterLink>Restore</FooterLink>
          <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
          <FooterLink>Privacy</FooterLink>
          <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
          <FooterLink>Terms</FooterLink>
        </div>
        <p className="mt-3 text-center text-[11px] text-muted-foreground/70">
          Auto‑renews until cancelled. Manage in Apple ID settings.
        </p>
      </div>
    </main>
  );
}

function SlideCard({ slide }: { slide: Slide }) {
  const Visual = slide.visual;
  const Icon = slide.icon;
  return (
    <div
      className="relative w-full shrink-0 snap-center px-5"
      style={{ scrollSnapAlign: "center" }}
    >
      {/* Visual */}
      <div className="relative h-[300px] overflow-hidden rounded-3xl border border-white/5 bg-[radial-gradient(120%_80%_at_50%_0%,rgba(225,6,0,0.15),transparent_60%),linear-gradient(180deg,#141414,#0a0a0a)]">
        <Visual />
      </div>

      {/* Overlay copy card */}
      <div className="glass-card relative -mt-16 rounded-3xl p-6 pt-7">
        <div className="mb-3 flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/15 ring-1 ring-primary/30">
            <Icon className="h-4 w-4 text-primary" strokeWidth={2.2} />
          </span>
          <span className="font-display text-[10px] font-bold uppercase tracking-[0.24em] text-primary/90">
            Redline Pro
          </span>
        </div>
        <h2 className="font-display text-[26px] font-black leading-[1.05] tracking-tight text-foreground">
          {slide.title}
        </h2>
        <ul className="mt-4 space-y-2">
          {slide.lines.map((l) => (
            <li key={l} className="flex items-start gap-2 text-[14px] leading-snug text-muted-foreground">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
              {l}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function FooterLink({ children }: { children: React.ReactNode }) {
  return <button className="underline-offset-4 transition-colors hover:text-foreground hover:underline">{children}</button>;
}

function PlanCard({
  selected,
  onSelect,
  title,
  subtitle,
  price,
  cadence,
  strike,
  badge,
}: {
  selected: boolean;
  onSelect: () => void;
  title: string;
  subtitle: string;
  price: string;
  cadence: string;
  strike?: string;
  badge?: string;
}) {
  return (
    <button
      onClick={onSelect}
      aria-pressed={selected}
      className={[
        "relative flex w-full items-center gap-4 rounded-2xl p-5 text-left transition-all",
        selected
          ? "bg-[linear-gradient(180deg,rgba(225,6,0,0.15),rgba(225,6,0,0.04))] ring-2 ring-primary shadow-[0_18px_50px_-18px_rgba(225,6,0,0.6)]"
          : "bg-card/60 ring-1 ring-white/8 hover:ring-white/15",
      ].join(" ")}
    >
      {badge && (
        <span className="absolute -top-2.5 right-5 rounded-full bg-primary px-2.5 py-1 font-display text-[10px] font-bold tracking-[0.14em] text-primary-foreground shadow-[0_6px_20px_-4px_rgba(225,6,0,0.8)]">
          {badge}
        </span>
      )}

      <span
        className={[
          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-all",
          selected ? "border-primary bg-primary" : "border-white/25 bg-transparent",
        ].join(" ")}
      >
        {selected && <Check className="h-3.5 w-3.5 text-primary-foreground" strokeWidth={3} />}
      </span>

      <div className="min-w-0 flex-1">
        <div className="font-display text-[17px] font-bold tracking-tight">{title}</div>
        <div className="mt-0.5 text-[12px] text-muted-foreground">{subtitle}</div>
      </div>

      <div className="text-right">
        {strike && (
          <div className="text-[11px] text-muted-foreground line-through">{strike}</div>
        )}
        <div className="font-display text-[20px] font-black tracking-tight tabular-nums">{price}</div>
        <div className="text-[11px] text-muted-foreground">{cadence}</div>
      </div>
    </button>
  );
}

/* ————————————————————————————— Visuals ————————————————————————————— */

function SpeedoVisual() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="relative h-56 w-56">
        <svg viewBox="0 0 200 200" className="absolute inset-0">
          <defs>
            <linearGradient id="ring" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#E10600" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#E10600" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          <circle cx="100" cy="100" r="86" stroke="rgba(255,255,255,0.06)" strokeWidth="10" fill="none" />
          <circle
            cx="100"
            cy="100"
            r="86"
            stroke="url(#ring)"
            strokeWidth="10"
            strokeLinecap="round"
            fill="none"
            strokeDasharray="540"
            strokeDashoffset="140"
            transform="rotate(-90 100 100)"
          />
          <circle cx="171" cy="130" r="4" fill="#E10600" />
        </svg>
        <div className="absolute inset-0 grid place-items-center text-center">
          <div>
            <div className="font-display text-[52px] font-black leading-none tracking-tight">142</div>
            <div className="mt-1 font-display text-[11px] font-bold uppercase tracking-[0.3em] text-muted-foreground">
              KM/H
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LeaderboardVisual() {
  const rows = [
    { n: "marco.rs", v: "198", m: "🥇" },
    { n: "jake.m", v: "185", m: "🥈" },
    { n: "luka.a6", v: "172", m: "🥉" },
  ];
  return (
    <div className="absolute inset-0 flex flex-col justify-center gap-2 px-5">
      {rows.map((r, i) => (
        <div
          key={r.n}
          className={[
            "flex items-center gap-3 rounded-xl border p-3",
            i === 0
              ? "border-primary/50 bg-primary/10"
              : "border-white/8 bg-white/[0.03]",
          ].join(" ")}
        >
          <span className="text-xl">{r.m}</span>
          <div className="min-w-0 flex-1">
            <div className="font-display text-[14px] font-bold">{r.n}</div>
            <div className="text-[11px] text-muted-foreground">Friend</div>
          </div>
          <div className="text-right">
            <div className="font-display text-[18px] font-black tabular-nums text-primary">{r.v}</div>
            <div className="text-[10px] text-muted-foreground">km/h</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function RecordingsVisual() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="relative">
        <InfinityIcon className="h-40 w-40 text-primary" strokeWidth={1.2} />
        <div className="absolute inset-0 blur-2xl opacity-40">
          <InfinityIcon className="h-40 w-40 text-primary" strokeWidth={1.2} />
        </div>
        <div className="mt-4 text-center font-display text-[11px] font-bold uppercase tracking-[0.3em] text-muted-foreground">
          Unlimited Sessions
        </div>
      </div>
    </div>
  );
}

function AlertsVisual() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="relative flex flex-col items-center gap-4">
        <div className="relative">
          <div className="absolute inset-0 animate-ping rounded-full bg-primary/40" />
          <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-primary shadow-[0_0_40px_rgba(225,6,0,0.7)]">
            <Bell className="h-9 w-9 text-primary-foreground" strokeWidth={2.2} />
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/60 px-4 py-3 backdrop-blur">
          <div className="font-display text-[12px] font-bold uppercase tracking-widest text-primary">
            Record Broken
          </div>
          <div className="text-[13px] text-foreground">jake.m just beat your top speed</div>
        </div>
      </div>
    </div>
  );
}

function InvitesVisual() {
  const bubbles = [
    { me: false, t: "Join my Redline board 🏁" },
    { me: true, t: "On it. Let's go." },
    { me: false, t: "🔥🔥🔥" },
  ];
  return (
    <div className="absolute inset-0 flex flex-col justify-center gap-2 px-6">
      {bubbles.map((b, i) => (
        <div key={i} className={b.me ? "flex justify-end" : "flex justify-start"}>
          <div
            className={[
              "max-w-[70%] rounded-2xl px-3.5 py-2 text-[13px]",
              b.me
                ? "bg-primary text-primary-foreground rounded-br-md"
                : "bg-white/8 text-foreground rounded-bl-md",
            ].join(" ")}
          >
            {b.t}
          </div>
        </div>
      ))}
    </div>
  );
}

function ChallengesVisual() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="flex flex-col items-center gap-3">
        <div className="flex items-center gap-2 rounded-full bg-primary/15 px-3 py-1.5 ring-1 ring-primary/40">
          <Flag className="h-3.5 w-3.5 text-primary" />
          <span className="font-display text-[10px] font-bold uppercase tracking-[0.24em] text-primary">
            Active Challenge
          </span>
        </div>
        <div className="rounded-2xl border border-white/10 bg-black/50 px-6 py-5 text-center backdrop-blur">
          <div className="text-[12px] uppercase tracking-widest text-muted-foreground">Prize Pool</div>
          <div className="mt-1 font-display text-[42px] font-black leading-none text-primary">
            $250
          </div>
          <div className="mt-3 flex items-center justify-center gap-3 font-display text-[14px] font-bold tabular-nums">
            <TimeBlock v="02" l="D" />
            <span className="text-muted-foreground">:</span>
            <TimeBlock v="14" l="H" />
            <span className="text-muted-foreground">:</span>
            <TimeBlock v="37" l="M" />
          </div>
        </div>
      </div>
    </div>
  );
}

function TimeBlock({ v, l }: { v: string; l: string }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-foreground">{v}</span>
      <span className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">{l}</span>
    </div>
  );
}

function SoundtrackVisual() {
  const bars = [30, 60, 45, 80, 55, 90, 40, 70, 50, 85, 35, 65, 50, 78, 42];
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 px-6">
      <div className="flex h-24 items-end gap-1.5">
        {bars.map((h, i) => (
          <div
            key={i}
            className="w-2 rounded-full bg-gradient-to-t from-primary/40 to-primary"
            style={{
              height: `${h}%`,
              animation: `rise-in 700ms ${i * 40}ms both`,
            }}
          />
        ))}
      </div>
      <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/50 px-4 py-3 backdrop-blur">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
          <Music className="h-4 w-4 text-primary" />
        </div>
        <div>
          <div className="font-display text-[13px] font-bold">Night Run</div>
          <div className="text-[11px] text-muted-foreground">Attached to your recap</div>
        </div>
        <Gauge className="ml-4 h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
}